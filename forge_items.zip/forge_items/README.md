# forge_items (Luanti + Mineclonia)

Privilège unique pour TOUT : /grant <joueur> add_items   (ou /grantme add_items)

## Forger
Tiens l'item en main (enchantements conservés), puis :

    /add_items <nom> [effets|no] [infini yes|no]

- Le nom est UN SEUL mot : utilise _ pour les espaces (Epee_de_feu -> ¥£Epee de feu™).
- Les symboles autour sont réglables : forge_items.name_prefix / name_suffix.
- Effets (optionnels) : id:niveau séparés par des virgules, SANS espace.
  "no" = aucun effet. Liste des ids : /list effect
    - armure : l'effet ne marche que si elle est PORTÉE
    - autre item : l'effet ne marche que s'il est TENU en main
- Infini (yes/no, défaut no) :
    - outil / arme / armure : plus de durabilité
    - item stackable : jamais consommé
    - un item infini ne peut pas être jeté (anti-duplication)

Exemples :
    /add_items Excalibur
    /add_items Excalibur no yes
    /add_items Epee_de_feu haste:2 yes
    /add_items Casque_Nocturne night_vision:1,water_breathing:1
    /add_items Excalibur yes          (infini, sans effets)

## Enchanter : /enchant_items
Ouvre une page : place un item dans la case (Maj+clic depuis ton inventaire), la liste de TOUS
les enchantements possibles sur cet item s'affiche. Clique sur Add, entre le niveau.
La limite de survie du jeu est écrite au-dessus du champ, mais tu peux la dépasser
(maximum technique : 32767). L'item est rendu à la fermeture de la page.

## Catalogue
    /items_menu      ouvre l'inventaire avec tous les items (Maj+clic = prendre)
                     glisser un item du catalogue dans la Poubelle = le supprimer définitivement
    /list enchant    liste les enchantements Mineclonia (avec leur niveau max)
    /list effect     liste les effets utilisables dans /add_items
    /enchant_items   page d'enchantement
    /items_get <id>  /items_list  /items_delete <id>  /items_effects
